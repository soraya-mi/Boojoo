import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:boojoo/MoodTracker/moodTracker_database.dart';
import 'package:flutter/gestures.dart';
//import 'indicator.dart';
// void main(){
//   runApp(chartMaker());
// }
int countmood1Yearly=0;
int countmood2Yearly=0;
int countmood3Yearly=0;
int countmood4Yearly=0;
int countmood5Yearly=0;
void getDataFormMDDB()async {
  MoodTrackerDataBaseHelper moodtrackerDBinstance = MoodTrackerDataBaseHelper();
  final resDBMoodTracker = await moodtrackerDBinstance.getAllLogsMap();
  final res2DB=await moodtrackerDBinstance.getYearyLog("2021/");

  print("??????????????????????????????????/");
  //print(resDBMoodTracker);
  print("??????????????????????????????????/");
  print(res2DB);
  print("??????????????????????????????????/");
  print(((res2DB[res2DB.length-1].values).last).runtimeType);
  if((res2DB[res2DB.length-1].values).last==1)
    countmood1Yearly+=1;
  if((res2DB[res2DB.length-1].values).last==2)
    countmood2Yearly+=1;
  if((res2DB[res2DB.length-1].values).last==3)
    countmood3Yearly+=1;
  if((res2DB[res2DB.length-1].values).last==4)
    countmood4Yearly+=1;
  if((res2DB[res2DB.length-1].values).last==5)
    countmood5Yearly+=1;
  print((res2DB[res2DB.length-1].values).last);
  print("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
  print(countmood1Yearly);
  print("MOTHLYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
  print(countmood2Yearly);
  print("MOTHLYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
  print(countmood3Yearly);
  print("MOTHLYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
  print(countmood4Yearly);
  print("MOTHLYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
  print(countmood5Yearly);
  print("MOTHLYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
}
class chartMakerYearly extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    getDataFormMDDB();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PieChartSample2Yearly(),

    );
  }
}

class PieChartSample2Yearly extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => PieChart2StateYearly();
}

class PieChart2StateYearly extends State {
  int touchedIndex = -1;



  @override

  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.3,
      child: Card(
        color: Colors.white,
        child:SingleChildScrollView(
          child: Column(

            children: <Widget>[
              const SizedBox(
                height: 2,
              ),
              SingleChildScrollView(
                child: AspectRatio(
                  aspectRatio:1,
                  child: PieChart(
                    PieChartData(

                      // pieTouchData: PieTouchData(touchCallback: (pieTouchResponse) {
                      //   setState(() {
                      //     final desiredTouch = pieTouchResponse.touchInput is! PointerExitEvent &&
                      //         pieTouchResponse.touchInput is! PointerUpEvent;
                      //     if (desiredTouch && pieTouchResponse.touchedSection != null) {
                      //       touchedIndex = pieTouchResponse.touchedSection!.touchedSectionIndex;
                      //     } else {
                      //       touchedIndex = -1;
                      //     }
                      //   });
                      // }),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        sectionsSpace: 5,
                        centerSpaceRadius: 40,
                        sections: showingSections()),
                  ),
                ),
              ),

              Column(
                // mainAxisSize: MainAxisSize.max,
                // mainAxisAlignment: MainAxisAlignment.end,
                // crossAxisAlignment: CrossAxisAlignment.start,
                children:  <Widget>[
                  Container(
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    alignment: Alignment.center,
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:  <Widget>[
                        Icon(
                          Icons.sentiment_very_dissatisfied,
                          color: Colors.red,
                        ),
                        Text("خیلی ناراضیم "),

                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    alignment: Alignment.center,
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:  <Widget>[
                        Icon(
                          Icons.sentiment_dissatisfied,
                          color: Colors.deepOrange,
                        ),
                        Text(" ناراضیم "),

                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    alignment: Alignment.center,
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:  <Widget>[
                        Icon(
                          Icons.sentiment_neutral,
                          color: Colors.amber,
                        ),
                        Text("معمولیم "),

                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    alignment: Alignment.center,
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:  <Widget>[
                        Icon(
                          Icons.sentiment_satisfied,
                          color: Colors.lightGreen,
                        ),
                        Text("راضیم "),

                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    alignment: Alignment.center,
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:  <Widget>[
                        Icon(
                          Icons.sentiment_very_satisfied,
                          color: Colors.green,
                        ),
                        Text("خیلی راضیم "),

                      ],
                    ),

                  ),
                  SizedBox(height: 20,),

                ],
              ),
              const SizedBox(
                width: 28,
              ),
            ],
          ),
        ),
      ),
    );

  }

  List<PieChartSectionData> showingSections() {
    getDataFormMDDB();
    List YearlyList=[countmood1Yearly,countmood2Yearly,countmood3Yearly,countmood4Yearly,countmood5Yearly];
    countmood5Yearly=0;
    countmood4Yearly=0;
    countmood3Yearly=0;
    countmood2Yearly=0;
    countmood1Yearly=0;
    int countmood5YearlyA=YearlyList[4];
    int countmood4YearlyA=YearlyList[3];
    int countmood3YearlyA=YearlyList[2];
    int countmood2YearlyA=YearlyList[1];
    int countmood1YearlyA=YearlyList[0];
    return List.generate(5, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      switch (i) {
        case 2:
          return PieChartSectionData(
            color: Colors.red,
            value:countmood1YearlyA/1,
            title: '${((countmood1YearlyA*100)/30).toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize, fontWeight: FontWeight.bold, color: Colors.white),
          );
        case 0:
          return PieChartSectionData(
            color: Colors.deepOrange,
            value:countmood2YearlyA/1,
            title: '${((countmood2YearlyA*100)/30).toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize, fontWeight: FontWeight.bold, color: Colors.white),
          );
        case 4:
          return PieChartSectionData(
            color: Colors.amber,
            value: countmood3YearlyA/1,
            title: '${((countmood3YearlyA*100)/30).toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize, fontWeight: FontWeight.bold, color: Colors.white),
          );
        case 3:
          return PieChartSectionData(
            color: Colors.lightGreen,
            value: countmood4YearlyA/1,
            title: '${((countmood4YearlyA*100)/30).toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize, fontWeight: FontWeight.bold, color: Colors.white),
          );
        case 1:
          return PieChartSectionData(
            color:Colors.green,
            value: countmood5YearlyA/1,
            title: '${((countmood5YearlyA*100)/30).toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize, fontWeight: FontWeight.bold, color: Colors.white),
          );
        default:
          throw Error();
      }
    });
  }
}