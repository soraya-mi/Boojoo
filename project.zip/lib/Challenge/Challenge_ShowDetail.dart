import 'package:boojoo/Challenge/Challenge_Detail.dart';
import 'package:flutter/material.dart';

class challenge_show extends StatefulWidget {
  @override
  _challenge_showState createState() => _challenge_showState();
}

class _challenge_showState extends State<challenge_show> {



  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
