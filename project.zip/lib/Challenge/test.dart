import 'package:flutter/material.dart';

class show extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
        title: Text('پروفایل'),
      )
    );
  }
}


